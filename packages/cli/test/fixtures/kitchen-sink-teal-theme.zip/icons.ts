/**
 * Icon configuration exported from the UI Organized Theme Builder.
 *
 * Icons are runtime React context, not CSS. Wrap your app with <IconProvider>
 * so every <Icon> inherits the chosen library, style, reference size and stroke
 * scaling.
 *
 * Two things to install and import:
 *
 *   npm i lucide-react
 *
 *   import "@ui-organized/react/icons/lucide";   // registers the icon set
 *   import { IconProvider } from "@ui-organized/react";
 *
 * Then register the icons you name, under lucide's own names. Nothing is
 * renamed, and only what you register reaches your bundle:
 *
 *   import { registerIcons } from "@ui-organized/react/icons/lucide";
 *   registerIcons({ ...the lucide-react icons you use });
 *   import { iconConfig } from "./icons";
 *
 *   <IconProvider {...iconConfig}>
 *     <App />
 *   </IconProvider>
 *
 * The subpath import is required: @ui-organized/react imports no icon library
 * itself, which is what keeps the two you didn't choose out of your bundle.
 */
import type { IconConfig } from "@ui-organized/react";

export const iconConfig: IconConfig = {
  library: "lucide",
  style: "outline",
  strokeAdjustment: false,
  baseSize: 24,
  baseStroke: 2,
};
